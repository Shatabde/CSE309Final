<div class="w-full">
    <footer class="bg-gray-800 text-white py-2 mt-4 text-sm">
        <div class="container mx-auto text-center">
          <p>&copy; 2023 BookNest. All Rights Reserved.</p>
          <p class="mt-2">123 Library Street, Dhaka, Bangladesh.</p>
          <i class="fab fa-github text-white px-4" aria-hidden="true"></i>
          <i class="fab fa-facebook" aria-hidden="true"></i>
        </div>
      </footer>
   </div>